#region Call base image startup script, which sets up monitoring (W3SVC, file/event logs) and performs config file variable injection
	$FileLogsToMonitor = @("C:\logs\*.log")

	C:\Scripts\Monitor-Container.ps1 `
		-ServiceToMonitor "W3SVC" `
		-FileLogsToMonitor $FileLogsToMonitor `
		-EventLogsToMonitor @() `
		-ConfigurationFiles @{}
#endregion
